import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Trash3 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trash3 extends Eatable
{
    /**
     * Act - do whatever the Trash3 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Trash3() 
    {
        GreenfootImage img = getImage();
        img.scale(50, 50);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
