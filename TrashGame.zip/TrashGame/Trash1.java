import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Trash1 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Trash1 extends Eatable
{
    /**
     * Act - do whatever the Trash1 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Trash1() 
    {
        GreenfootImage img = getImage();
        img.scale(50, 50);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
