import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Warning here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Warning extends Objects
{
    /**
     * Act - do whatever the Warning wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public Warning()
    {
        GreenfootImage img = getImage();
        img.scale(200, 100);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
