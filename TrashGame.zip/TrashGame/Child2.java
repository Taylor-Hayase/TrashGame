import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Child2 here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Child2 extends NPC
{
    /**
     * Act - do whatever the Child2 wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    
    public Child2() {
        GreenfootImage img = getImage();
        img.scale(65, 65);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
