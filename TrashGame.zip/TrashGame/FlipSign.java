import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FlipSign here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlipSign extends Objects
{
    /**
     * Act - do whatever the FlipSign wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public FlipSign()
    {
        GreenfootImage img = getImage();
        img.scale(75, 75);
    }
    
    public void act() 
    {
        // Add your action code here.
    }    
}
